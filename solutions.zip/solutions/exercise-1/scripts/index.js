let input = prompt("Please enter your name: ");
console.log("Your name is: ", input);
