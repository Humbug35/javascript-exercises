let input = prompt("Please enter a number: ");
console.log("Result: ", input*input);
