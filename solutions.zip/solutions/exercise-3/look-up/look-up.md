The multiplication sign (*) is not overloaded to signify other operations, as is the case
with addition (+). The latter can be used to concatenate strings, and also to add numerical
values.