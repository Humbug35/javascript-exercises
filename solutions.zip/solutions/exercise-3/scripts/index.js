let number1 = parseInt(prompt("Please enter first number: "));
let number2 = parseInt(prompt("Please enter second number: "));
console.log("Result: ", number1+number2);

